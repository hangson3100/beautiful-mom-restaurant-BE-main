const { getMySqlPromiseConnection } = require('../config/mysql.db');
const { parseOrderAddons } = require('../utils/orderAddons');

exports.getKitchenOrdersDB = async () => {
  const conn = await getMySqlPromiseConnection();
  try {
    const sql = `
    SELECT
      o.id,
      o.date,
      o.delivery_type,
      o.customer_type,
      o.customer_id,
      c. \`name\` AS customer_name,
      c.phone AS customer_phone,
      c.address AS customer_address,
      o.receive_time,
      o.table_id,
      st.table_title,
      st. \`floor\`,
      o.status,
      o.payment_status,
      o.token_no
    FROM
      orders o
      LEFT JOIN customers c ON o.customer_id = c.phone
      LEFT JOIN store_tables st ON o.table_id = st.id
    WHERE
      date >= DATE_SUB(NOW(), INTERVAL 1 DAY)
      AND date <= DATE_ADD(NOW(), INTERVAL 1 DAY)
      AND o.status NOT IN ('completed', 'cancelled')
    `;

    const [kitchenOrders] = await conn.query(sql);

    let kitchenOrdersItems = [];
    let addons = [];

    if (kitchenOrders.length > 0) {
      const orderIds = kitchenOrders.map((o) => o.id).join(',');
      const sql2 = `
      SELECT
        oi.id,
        oi.order_id,
        oi.item_id,
        mi.title AS item_title,
        mi.price,
        oi.price AS order_price,
        t.rate AS tax_rate,
        t.type AS tax_type,
        oi.variant_id,
        miv.title as variant_title,
        miv.price AS variant_price,
        oi.quantity,
        oi.status,
        oi.date,
        oi.addons,
        oi.notes
      FROM
        order_items oi
        LEFT JOIN menu_items mi ON oi.item_id = mi.id
        LEFT join menu_item_variants miv ON oi.item_id = miv.item_id AND oi.variant_id = miv.id
        LEFT JOIN taxes t ON mi.tax_id = t.id

      WHERE oi.order_id IN (${orderIds})
      `;
      const [kitchenOrdersItemsResult] = await conn.query(sql2);
      kitchenOrdersItems = kitchenOrdersItemsResult;

      const addonIds = [
        ...new Set([
          ...kitchenOrdersItems.flatMap((o) =>
            parseOrderAddons(o.addons).ids
          ),
        ]),
      ].join(',');
      const [addonsResult] = addonIds
        ? await conn.query(
            `SELECT id, item_id, title, price FROM menu_item_addons WHERE id IN (${addonIds});`
          )
        : [];
      addons = addonsResult;
    }

    const [[storeSettings], [printSettings]] = await Promise.all([
      conn.query(
        `SELECT store_name, address, phone, currency FROM store_details WHERE id = 1 LIMIT 1`
      ),
      conn.query(
        `SELECT page_format, header, footer FROM print_settings WHERE id = 1 LIMIT 1`
      ),
    ]);

    return {
      kitchenOrders,
      kitchenOrdersItems,
      addons,
      storeSettings: storeSettings || null,
      printSettings: printSettings || null,
    };
  } catch (error) {
    console.error(error);
    throw error;
  } finally {
    conn.release();
  }
};

exports.updateOrderItemStatusDB = async (orderItemId, status) => {
  const conn = await getMySqlPromiseConnection();
  try {
    const sql = `
    UPDATE order_items SET
    status = ?
    WHERE id = ?;
    `;

    await conn.query(sql, [status, orderItemId]);
    return;
  } catch (error) {
    console.error(error);
    throw error;
  } finally {
    conn.release();
  }
};
