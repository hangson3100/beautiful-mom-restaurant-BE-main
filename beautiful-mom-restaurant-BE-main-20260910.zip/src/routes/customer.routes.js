const { Router } = require("express");

const {
  isLoggedIn,
  isAuthenticated,
  authorize,
} = require("../middlewares/auth.middleware");
const { SCOPES } = require("../config/user.config");
const {
  addCustomer,
  getCustomers,
  updateCustomer,
  deleteCustomer,
  getCustomer,
  searchCustomer,
} = require("../controllers/customer.controller");

const router = Router();

router.post(
  "/add",
  isLoggedIn,
  isAuthenticated,
  authorize([SCOPES.MANAGE_CUSTOMERS]),
  addCustomer
);

router.get(
  "/",
  isLoggedIn,
  isAuthenticated,
  authorize([SCOPES.CUSTOMERS, SCOPES.VIEW_CUSTOMERS]),
  getCustomers
);
router.get(
  "/:id",
  isLoggedIn,
  isAuthenticated,
  authorize([SCOPES.CUSTOMERS, SCOPES.VIEW_CUSTOMERS]),
  getCustomer
);
router.get(
  "/search-by-phone-name/search",
  isLoggedIn,
  isAuthenticated,
  authorize([SCOPES.CUSTOMERS, SCOPES.VIEW_CUSTOMERS]),
  searchCustomer
);

router.post(
  "/:id/update",
  isLoggedIn,
  isAuthenticated,
  authorize([SCOPES.CUSTOMERS, SCOPES.MANAGE_CUSTOMERS]),
  updateCustomer
);
router.delete(
  "/:id/delete",
  isLoggedIn,
  isAuthenticated,
  authorize([SCOPES.CUSTOMERS, SCOPES.MANAGE_CUSTOMERS]),
  deleteCustomer
);

module.exports = router;
